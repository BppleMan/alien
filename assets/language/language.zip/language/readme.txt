异形：隔离虎头汉化-全版本适用-适配完整DLC.V1.1.3

说明：
使用截至2022年12月11日最新GOG版完整DLC的异形：隔离游戏汉化测试，正常使用，无替换游戏可执行程序，完美适配全版本，steam&deck epic gog xgp 均可用。
自制简体字库，使用的开源免费字体：
未来荧黑·未來熒黑 (https://github.com/welai/glow-sans)
Fonsung | 坊宋 (https://diaowinner.itch.io/fonsung)
Taipei Fonts | 台北字體 (https://diaowinner.itch.io/taipei-fonts)

使用方法：
解压缩后将 DATA 文件夹复制到游戏安装的文件夹目录，注意做好原文件的备份以便可回到英文版本。

特别感谢：
汉化文本基于坛友@3DFox、@eareach、@御坂10032。
他们的帖子依次为：
https://keylol.com/t202106-1-1
https://keylol.com/t209218-1-1
https://keylol.com/t527436-1-1

在此向各位以及KEYLOL论坛表示感谢！

制作：sjh00
2022年12月
转载请注明制作者及出处。

更新记录：
V1.1.3
根据其友@Arctic1979反馈DLC部分汉化情况做出更新
V1.1.2
还原部分可以不翻译的地名和特有名词，方便游戏中寻找（Sevastopol、San Cristobal、Seegson、Weyland-Yutani、APOLLO）
修正部分俚语翻译（Working Joe——“打工仔”）
修改部分特有名词翻译（USCSS Nostromo、USCSS Torrens）
修改A1_M1301部分汉化
V1.1.0
更新字体库，尽可能还原游戏原字体风格
初步增加繁体版本的汉化
跟进更新@御坂10032的汉化文本
修改部分汉化文本以更好配合字体展现
V1.0.2
修正部分符号的显示问题
V1.0.1
修正字体适用范围
修正部分文字不显示问题


BTW
跳过开头冗长的LOGO动画方法：
进入游戏目录下找到DATA\UI\MOVIES，重命名以下三个文件后缀名为.USMBAK，或者直接删除文件即可：
1.FOX_IDENT.USM第一个开头动画
2.CA_IDENT.USM第二个开头动画
3.AMD_IDENT.USM第三个开头动画